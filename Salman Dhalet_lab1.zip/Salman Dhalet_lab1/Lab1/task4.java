			// Task 04:Salman Alias Adnan
	public class task4{
	public static void main (String [] args){

	System.out.println("Final result is = "+(10+5)*(4-6)/4);
}
}	
			
